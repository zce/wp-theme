<?php
get_header();
include("inc/content.php");
include("comment.php");
get_footer(); ?>