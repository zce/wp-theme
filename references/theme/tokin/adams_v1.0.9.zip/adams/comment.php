    <!-- Comments -->
    <section class="comments">
        <div class="container" data-no-instant>
            <?php comments_template();?>
        </div>
    </section>